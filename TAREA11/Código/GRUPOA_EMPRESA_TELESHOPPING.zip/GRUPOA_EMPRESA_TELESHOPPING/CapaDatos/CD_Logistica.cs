﻿using CapaDatos;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class CD_Logistica
    {
        // Instancia de la clase de conexión a la base de datos
        private CD_Connection conn = new CD_Connection();

        /// <summary>
        /// Obtiene un DataTable con la información de la logística.
        /// </summary>
        /// <returns>DataTable con la información de la logística.</returns>
        public DataTable getLogistica()
        {
            // DataTable para almacenar los resultados de la consulta
            DataTable dt = new DataTable();

            // Comando SQL para ejecutar la consulta
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter adapter;

            // Abre la conexión 
            cmd.Connection = conn.AbrirConexion();

            // Establece el comando como un procedimiento almacenado
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_GetEnvio"; // Nombre del procedimiento almacenado

            // Ejecuta y asigna al adaptador
            adapter = new SqlDataAdapter(cmd);

            // Asigna los resultados al DataTable
            adapter.Fill(dt);

            return dt;
        }

        /// <summary>
        /// Registra un nuevo envío en el sistema de logística.
        /// </summary>
        /// <param name="destinatario">Nombre del destinatario del envío.</param>
        /// <param name="fecha">Fecha de envío.</param>
        /// <param name="transporte">Método de transporte utilizado.</param>
        /// <param name="descripcion">Descripción del envío.</param>
        /// <param name="precio">Precio del envío.</param>
        /// <returns>True si el envío se registró exitosamente, de lo contrario, false.</returns>
        public bool EnviarLogistica(string destinatario, string fecha, string transporte, string descripcion, decimal precio)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn.AbrirConexion();

            // Establece el comando como un procedimiento almacenado
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_EnviarLogistica"; // Nombre del procedimiento almacenado

            // Agrega parámetros al comando
            cmd.Parameters.AddWithValue("@Destinatario", destinatario);
            cmd.Parameters.AddWithValue("@Fecha_envio", fecha);
            cmd.Parameters.AddWithValue("@Transporte", transporte);
            cmd.Parameters.AddWithValue("@Descripcion", descripcion);
            cmd.Parameters.AddWithValue("@Precio", precio);

            cmd.ExecuteNonQuery();
            conn.CerrarConexion();

            return true;
        }
    }
}
