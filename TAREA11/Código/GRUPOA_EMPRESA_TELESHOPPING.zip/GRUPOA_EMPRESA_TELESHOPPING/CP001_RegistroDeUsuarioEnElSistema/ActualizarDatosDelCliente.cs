﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaPresentacion;
using NUnit.Framework;
using System;

    namespace Pruebas
    {
        [TestFixture]
        public class UsuarioDatosTests
        {
            private UsuarioDatos usuarioDatos;
            private string connectionString = "Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True";

            [OneTimeSetUp]
            public void OneTimeSetUp()
            {
                // Configura la conexión a la base de datos si es necesario para tus pruebas
                usuarioDatos = new UsuarioDatos(connectionString);
            }

          

            [Test]
            public void BuscarUsuarioPorCIIncorrecto()
            {
                // Arrange: Preparación de datos para la prueba
                string ci = "1234567890"; // Un CI que no existe en la base de datos

                // Act: Acción que se está probando
                Usuario usuario = usuarioDatos.BuscarUsuarioPorCI(ci);

                // Assert: Verificar el resultado esperado
                Assert.IsNull(usuario, "El usuario no debería ser encontrado.");
            }

            [Test]
            public void ActualizarUsuarioExitoso()
            {
                // Arrange: Preparación de datos para la prueba
                Usuario usuario = new Usuario
                {
                    CI = "0950722823",
                    NombreYApellido = "Camila Lopez",
                    Email = "CamilaL01@gmail.com",
                    Contrasena = "Camila08",
                    ConfirmarContrasena = "Camila08"
                };

                // Act: Acción que se está probando
                bool actualizacionExitosa = usuarioDatos.ActualizarUsuario(usuario);

                // Assert: Verificar el resultado esperado
                Assert.IsTrue(actualizacionExitosa, "La actualización de usuario debería ser exitosa.");
                // Verifica que los datos se hayan actualizado correctamente en la base de datos según tu implementación
            }

           
        }
    }


