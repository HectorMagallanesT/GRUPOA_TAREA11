﻿using System;

namespace CapaException
{
    /// <summary>
    /// Excepción personalizada para manejar errores relacionados con la autenticación.
    /// </summary>
    public class AutenticacionException : Exception
    {
        /// <summary>
        /// Inicializa una nueva instancia de la clase AutenticacionException.
        /// </summary>
        public AutenticacionException() : base() { }

        /// <summary>
        /// Inicializa una nueva instancia de la clase AutenticacionException con un mensaje de error personalizado.
        /// </summary>
        /// <param name="message">Mensaje de error personalizado.</param>
        public AutenticacionException(string message) : base(message) { }

        /// <summary>
        /// Inicializa una nueva instancia de la clase AutenticacionException con un mensaje de error personalizado
        /// y una excepción interna que causó esta excepción.
        /// </summary>
        /// <param name="message">Mensaje de error personalizado.</param>
        /// <param name="innerException">Excepción interna que causó esta excepción.</param>
        public AutenticacionException(string message, Exception innerException) : base(message, innerException) { }
    }
}
