﻿using CapaDatos;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class CN_Logistica
    {
        // Instancia de la clase CD_Logistica para manejar la lógica de envío
        private CD_Logistica manejadorEnvio = new CD_Logistica();

        /// <summary>
        /// Obtiene una lista de envíos desde la capa de datos.
        /// </summary>
        /// <returns>DataTable con la información de los envíos.</returns>
        public DataTable GetListaEnvio()
        {
            // Llama al método de la capa de datos para obtener la información de los envíos
            return manejadorEnvio.getLogistica();
        }

        /// <summary>
        /// Envía información de logística a la capa de datos para su registro.
        /// </summary>
        /// <param name="destinatario">Nombre del destinatario del envío.</param>
        /// <param name="fecha">Fecha de envío.</param>
        /// <param name="transporte">Método de transporte utilizado.</param>
        /// <param name="descripcion">Descripción del envío.</param>
        /// <param name="precio">Precio del envío.</param>
        public void EnviarLogistica(string destinatario, string fecha, string transporte, string descripcion, decimal precio)
        {
            // Llama al método de la capa de datos para enviar la información de logística
            manejadorEnvio.EnviarLogistica(destinatario, fecha, transporte, descripcion, precio);
        }
    }
}
