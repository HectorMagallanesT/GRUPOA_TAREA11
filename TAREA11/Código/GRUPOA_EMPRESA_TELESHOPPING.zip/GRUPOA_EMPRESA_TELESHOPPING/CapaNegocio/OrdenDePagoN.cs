﻿using System;
using CapaDatos;
using System.Data;

namespace CapaNegocio
{
    /// <summary>
    /// Clase que maneja la lógica de negocios relacionada con las órdenes de pago.
    /// </summary>
    public class OrdenDePagoN
    {
        private OrdenDePagoD ordenDePagoD = new OrdenDePagoD();

        /// <summary>
        /// Carga los datos de pago para un cliente específico.
        /// </summary>
        /// <param name="nombreYApellido">Nombre y apellido del cliente.</param>
        /// <returns>Un DataTable con los datos de pago del cliente.</returns>
        public DataTable CargarDatosPago(string nombreYApellido)
        {
            return ordenDePagoD.CargarDatosPago(nombreYApellido);
        }

        /// <summary>
        /// Actualiza un registro de pago existente.
        /// </summary>
        /// <param name="ci">Cédula de identidad del cliente.</param>
        /// <param name="nombreYApellido">Nombre y apellido del cliente.</param>
        /// <param name="email">Correo electrónico del cliente.</param>
        /// <param name="direccion">Dirección del cliente.</param>
        /// <param name="telf">Número de teléfono del cliente.</param>
        /// <param name="pago">Método de pago utilizado.</param>
        /// <param name="fechaHora">Fecha y hora de la transacción.</param>
        /// <param name="total">Monto total de la transacción.</param>
        /// <returns>True si la actualización se realizó con éxito, false en caso contrario.</returns>
        public bool ActualizarRegistro(string ci, string nombreYApellido, string email, string direccion, string telf, string pago, DateTime fechaHora, decimal total)
        {
            return ordenDePagoD.ActualizarRegistro(ci, nombreYApellido, email, direccion, telf, pago, fechaHora, total);
        }

        /// <summary>
        /// Elimina un registro de pago basado en la fecha y hora de la transacción.
        /// </summary>
        /// <param name="fechaHora">Fecha y hora de la transacción a eliminar.</param>
        /// <returns>True si la eliminación se realizó con éxito, false en caso contrario.</returns>
        public bool EliminarRegistro(DateTime fechaHora)
        {
            return ordenDePagoD.EliminarRegistro(fechaHora);
        }
    }
}
