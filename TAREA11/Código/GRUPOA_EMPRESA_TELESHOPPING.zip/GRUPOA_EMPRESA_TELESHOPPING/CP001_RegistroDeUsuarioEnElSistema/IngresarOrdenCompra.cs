﻿using NUnit.Framework;
using System;
using System.Data;
using System.Data.SqlClient;

namespace Pruebas
{
    [TestFixture]
    public class IngresarOrdenCompra
    {
        private string connectionString = "Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True";

        [Test]
        public void IngresarOrdenCompras()
        {
            // Configurar los parámetros de la orden de compra
            string ci = "0950678990";
            string nombreYApellido = "Hector Magallanes";
            string email = "hectorM08@gmail.com";
            string direccion = "Samanes";
            string telefono = "0989873458";
            string metodoPago = "Efectivo";
            DateTime fechaHora = DateTime.Parse("2023-11-05 16:24:02.120");
            decimal total = 20.00m;

            //Inserción de la orden de compra directamente en la base de datos
            IngresarOrdenEnBD(ci, nombreYApellido, email, direccion, telefono, metodoPago, fechaHora, total);

        }

        // Implementa esta función para insertar la orden de compra en la base de datos
        private void IngresarOrdenEnBD(string ci, string nombreYApellido, string email, string direccion, string telefono, string metodoPago, DateTime fechaHora, decimal total)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("sp_RealizarPago", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CI", ci);
                    command.Parameters.AddWithValue("@NombreYApellido", nombreYApellido);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Direccion", direccion);
                    command.Parameters.AddWithValue("@Telf", telefono);
                    command.Parameters.AddWithValue("@Pago", metodoPago);
                    command.Parameters.AddWithValue("@FechaHora", fechaHora);
                    command.Parameters.Add("@Total", SqlDbType.Decimal).Value = total;

                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
