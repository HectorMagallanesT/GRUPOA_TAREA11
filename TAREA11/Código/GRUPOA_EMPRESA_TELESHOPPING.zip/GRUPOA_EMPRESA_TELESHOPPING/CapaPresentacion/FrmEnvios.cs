﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{

    public partial class FrmEnvios : Form
    {
        // Instancia de la clase CN_Logistica para manejar la lógica de negocios de envíos
        private CN_Logistica negocioLogistica = new CN_Logistica();

        /// <summary>
        /// Constructor del formulario FrmEnvios.
        /// </summary>
        public FrmEnvios()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Manejador de eventos que se ejecuta al cargar el formulario.
        /// </summary>
        private void FrmEnvios_Load(object sender, EventArgs e)
        {
            // Inicializa los componentes del formulario
            InitializeComponent();

            // Establece el origen de datos del DataGridView usando la capa de negocio
            dgvLogistica.DataSource = negocioLogistica.GetListaEnvio();
        }

        /// <summary>
        /// Manejador de eventos para el clic en el botón "Enviar".
        /// </summary>
        private void BtnEnviar_Click_1(object sender, EventArgs e)
        {
            // Se valida cada campo de TextBox
            if (string.IsNullOrEmpty(txtDestinatario.Text))
            {
                error.SetError(txtDestinatario, "Ingrese el destinatario");
                return;
            }
            error.SetError(txtDestinatario, "");

            if (string.IsNullOrEmpty(txtDescripcionCompra.Text))
            {
                error.SetError(txtDescripcionCompra, "Ingrese la descripción");
                txtDescripcionCompra.Focus();
                return;
            }
            error.SetError(txtDescripcionCompra, "");

            if (string.IsNullOrEmpty(txtValorCompra.Text))
            {
                error.SetError(txtValorCompra, "Ingrese el precio");
                txtValorCompra.Focus();
                return;
            }
            error.SetError(txtValorCompra, "");

            // Llama al método de la capa de negocio para insertar el envío
            negocioLogistica.EnviarLogistica(
                txtDestinatario.Text,
                dtpFechaEnvio.Text,
                cmbTransporte.Text,
                txtDescripcionCompra.Text,
                decimal.Parse(txtValorCompra.Text)
            );

            // Muestra un mensaje de éxito
            MessageBox.Show("El envío se insertó exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Actualiza el origen de datos del DataGridView con la nueva información
            dgvLogistica.DataSource = negocioLogistica.GetListaEnvio();
        }

        /// <summary>
        /// Manejador de eventos para la tecla presionada en el TextBox de valor de compra.
        /// </summary>
        private void txtValorCompra_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verifica si la tecla presionada es un número o una tecla de control
            if (char.IsNumber(e.KeyChar) || char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                // Si la tecla no es un número ni una tecla de control, se maneja y se muestra un mensaje de error
                e.Handled = true;
                MessageBox.Show("Solo se permiten números", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
