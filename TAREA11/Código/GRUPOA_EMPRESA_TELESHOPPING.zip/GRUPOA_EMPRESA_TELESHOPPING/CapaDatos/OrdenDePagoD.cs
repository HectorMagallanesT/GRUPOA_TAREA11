﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class OrdenDePagoD
    {

        // Cadena de conexión a la base de datos
        private string connectionString = "Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True";

        /// <summary>
        /// Carga los datos de pago de un cliente específico.
        /// </summary>
        /// <param name="nombreYApellido">Nombre y apellido del cliente.</param>
        /// <returns>Un DataTable con los datos de pago del cliente.</returns>
        public DataTable CargarDatosPago(string nombreYApellido)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("CargarDatosPago", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@NombreYApellido", nombreYApellido);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        return dataTable;
                    }
                }
            }
        }

        /// <summary>
        /// Actualiza un registro de pago en la base de datos.
        /// </summary>
        /// <param name="ci">Cédula de identidad del cliente.</param>
        /// <param name="nombreYApellido">Nombre y apellido del cliente.</param>
        /// <param name="email">Correo electrónico del cliente.</param>
        /// <param name="direccion">Dirección del cliente.</param>
        /// <param name="telf">Número de teléfono del cliente.</param>
        /// <param name="pago">Método de pago del cliente.</param>
        /// <param name="fechaHora">Fecha y hora de la transacción.</param>
        /// <param name="total">Total del pago.</param>
        /// <returns>True si la actualización es exitosa, False en caso contrario.</returns>
        public bool ActualizarRegistro(string ci, string nombreYApellido, string email, string direccion, string telf, string pago, DateTime fechaHora, decimal total)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("ActualizarRegistroPago", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CI", ci);
                    command.Parameters.AddWithValue("@NombreYApellido", nombreYApellido);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Direccion", direccion);
                    command.Parameters.AddWithValue("@Telf", telf);
                    command.Parameters.AddWithValue("@Pago", pago);
                    command.Parameters.AddWithValue("@FechaHora", fechaHora);
                    command.Parameters.AddWithValue("@Total", total);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }



        /// <summary>
        /// Elimina un registro de pago de la base de datos por su fecha y hora.
        /// </summary>
        /// <param name="fechaHora">Fecha y hora del registro a eliminar.</param>
        /// <returns>True si se elimina con éxito, False si no se encuentra el registro.</returns>
        public bool EliminarRegistro(DateTime fechaHora)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("EliminarRegistroPago", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@FechaHora", fechaHora);

                    return command.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}
